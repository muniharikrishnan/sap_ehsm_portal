sap.ui.define([
	"ehsmportal/test/unit/controller/App.controller"
], function () {
	"use strict";
});
